package com.techtown.newstest_v2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.CustomViewHolder>{

    private ArrayList<Item> arrayList;

    public MainAdapter() {
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
        return new CustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Log.e("TAG", "position = " + position);
        holder.onBind(arrayList.get(position), position);
    }

    @Override
    public int getItemCount() {
        if (null != arrayList) {
            return arrayList.size();
        }
        return 0;
    }

    public void setArrayList(ArrayList<Item> list){
        Log.e("E","title"+list);
        this.arrayList = list;
        notifyDataSetChanged();
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        TextView number;
        TextView title;
        TextView provider;
        TextView date;
        ImageView imageView;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            number = (TextView) itemView.findViewById(R.id.number);
            title = (TextView) itemView.findViewById(R.id.title);
            provider = (TextView) itemView.findViewById(R.id.provider);
            date = (TextView) itemView.findViewById(R.id.date);
            imageView = (ImageView) itemView.findViewById(R.id.image);
        }

        public void onBind(Item item, int position) {
            number.setText(String.valueOf(position + 1));
            title.setText(item.title);
            provider.setText(item.provider);
            date.setText(item.date);
            Glide.with(itemView.getContext()).load(item.image).into(imageView);
        }
    }
}

