package com.techtown.newstest_v2;

import java.util.ArrayList;

public class NewsList {
    public ArrayList<Item> news = new ArrayList<>();
}
