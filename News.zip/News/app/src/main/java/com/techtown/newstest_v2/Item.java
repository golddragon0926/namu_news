package com.techtown.newstest_v2;

public class Item {
    public String title = "";
    public String type = "";
    public String category = "";
    public String provider = "";
    public String image = "";
    public String date = "";
}
