package com.techtown.newstest_v2;

public class NetResult {
    String code = "";
    Object result;
}
